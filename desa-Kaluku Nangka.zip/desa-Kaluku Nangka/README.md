# [Desaku - Desa Pagar Besi](https://desapagarbesi.net)

[Desaku](https://desapagarbesi.net) Merupakan sebuah web profil sederhana yang dibuat untuk Desa Kaluku Nangka, Kec. Bambaira, Kab. Pasangkayu.

## Preview

[![Desaku Preview](https://lh3.googleusercontent.com/VfQUu-Hu1U0BezrphuvdpZ93w5HsTvi3ptWBxxI-7teWMy4-K6e6CA06We3InAEQf7X-y7q3rbKKAU7gGqeA2zvdvjxyrx_DK-mfUnl583OoYwe9mp2AsrLXASFNV0jWKKy7KZV5duQxn5Wzup9sIbIxnYXkCNE1g7FkE1khsX0Q6GbbYtoqLsZPAFgZFgBfS6_NR7qAWMjDKuyn0e8ITVV4KF6p-euXRVIp6ImlMhrn8bdkqKcMTFyzitZ_r_5V0BWdZsGtx6NnkiSksDUWdUNmF0ssUr73O4iC1lnu-z9IJigFtpQzDdHx9VgulOEOGODltFMwtpJn8lXcVlxCDmbp9ycSlAVtpbXJoTjFAjnK4mhfmN0uKSXF4UbKxHGqS7D9ogZkdrt0UxqqRd7DKgMeU6OG7u5ksvhHNsxMYN4UpwpK9n1UQDyItSceyqoUGV_DICrXyNv_tzewGSYbWX_4x0nKFeOtxsoJWsuiMkkhoHeRdkvleaDPJW2tXECb5CQ2r2iYKXQtLd8JWYVrs3zkt7K-GWsTmt6OdnAq7mkoE3G_2FFP0Jd94jRdR8--7-AA4x807cN9zn1WYEQJJ1_7WuPmn1fcdeoHvfddUGIamDNCqmI8BDHiXOXziwfPtcqQyir6WVtqrwtmG3TsDUJkaaqfRCYu=w1026-h501-no)](https://desapagarbesi.net)

**[View Live Preview](https://desapagarbesi.net)**

## About

Desaku dibangun dengan berbasiskan tema Agency dari Start Bootstrap.<br/>

[Agency](https://startbootstrap.com/template-overviews/agency/) is a one page agency portfolio theme for [Bootstrap](http://getbootstrap.com/) created by [Start Bootstrap](http://startbootstrap.com/). This theme features several content sections, a responsive portfolio grid with hover effects, full page portfolio item modals, a responsive timeline, and a working PHP contact form.

## Copyright and License

Copyright 2020-2023 Blackrock Digital LLC. Code released under the [MIT](https://github.com/BlackrockDigital/startbootstrap-agency/blob/gh-pages/LICENSE) license.
